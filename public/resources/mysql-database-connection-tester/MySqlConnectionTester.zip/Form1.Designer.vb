﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.status = New System.Windows.Forms.Label()
        Me.connect = New System.Windows.Forms.Button()
        Me.disconnect = New System.Windows.Forms.Button()
        Me.host = New System.Windows.Forms.TextBox()
        Me.password = New System.Windows.Forms.TextBox()
        Me.database = New System.Windows.Forms.TextBox()
        Me.user = New System.Windows.Forms.TextBox()
        Me.options = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'status
        '
        Me.status.Location = New System.Drawing.Point(12, 115)
        Me.status.Name = "status"
        Me.status.Size = New System.Drawing.Size(167, 17)
        Me.status.TabIndex = 0
        Me.status.Text = "Status: Disconnected"
        Me.status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'connect
        '
        Me.connect.Location = New System.Drawing.Point(8, 137)
        Me.connect.Name = "connect"
        Me.connect.Size = New System.Drawing.Size(70, 23)
        Me.connect.TabIndex = 1
        Me.connect.Text = "Connect"
        Me.connect.UseVisualStyleBackColor = True
        '
        'disconnect
        '
        Me.disconnect.Enabled = False
        Me.disconnect.Location = New System.Drawing.Point(81, 137)
        Me.disconnect.Name = "disconnect"
        Me.disconnect.Size = New System.Drawing.Size(70, 23)
        Me.disconnect.TabIndex = 2
        Me.disconnect.Text = "Disconnect"
        Me.disconnect.UseVisualStyleBackColor = True
        '
        'host
        '
        Me.host.Location = New System.Drawing.Point(12, 12)
        Me.host.Name = "host"
        Me.host.Size = New System.Drawing.Size(167, 20)
        Me.host.TabIndex = 3
        Me.host.Text = "Host..."
        '
        'password
        '
        Me.password.Location = New System.Drawing.Point(12, 90)
        Me.password.Name = "password"
        Me.password.Size = New System.Drawing.Size(167, 20)
        Me.password.TabIndex = 4
        Me.password.Text = "Password..."
        '
        'database
        '
        Me.database.Location = New System.Drawing.Point(12, 64)
        Me.database.Name = "database"
        Me.database.Size = New System.Drawing.Size(167, 20)
        Me.database.TabIndex = 5
        Me.database.Text = "Database..."
        '
        'user
        '
        Me.user.Location = New System.Drawing.Point(12, 38)
        Me.user.Name = "user"
        Me.user.Size = New System.Drawing.Size(167, 20)
        Me.user.TabIndex = 6
        Me.user.Text = "User..."
        '
        'options
        '
        Me.options.Location = New System.Drawing.Point(154, 137)
        Me.options.Name = "options"
        Me.options.Size = New System.Drawing.Size(32, 23)
        Me.options.TabIndex = 7
        Me.options.Text = "..."
        Me.options.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(192, 169)
        Me.Controls.Add(Me.options)
        Me.Controls.Add(Me.user)
        Me.Controls.Add(Me.database)
        Me.Controls.Add(Me.password)
        Me.Controls.Add(Me.host)
        Me.Controls.Add(Me.disconnect)
        Me.Controls.Add(Me.connect)
        Me.Controls.Add(Me.status)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MySql Connection Tester"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents status As Label
    Friend WithEvents connect As Button
    Friend WithEvents disconnect As Button
    Friend WithEvents host As TextBox
    Friend WithEvents password As TextBox
    Friend WithEvents database As TextBox
    Friend WithEvents user As TextBox
    Friend WithEvents options As Button
End Class
