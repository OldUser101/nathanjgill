﻿Public Class Form2

    Private Sub passwordChar_CheckedChanged(sender As Object, e As EventArgs) Handles usePasswordChar.CheckedChanged
        If usePasswordChar.Checked = True Then
            passwordChar.ReadOnly = False
        Else
            passwordChar.ReadOnly = True
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        My.Settings.resetDataOnFail = resetOnFail.CheckState
        My.Settings.readOnlyDataOnConnected = readOnlyData.CheckState
        My.Settings.resetOnDisconnected = resetOnDisconnect.CheckState
        My.Settings.usePasswordChar = usePasswordChar.CheckState
        My.Settings.passwordChar = passwordChar.Text
        My.Settings.Save()
        Me.DialogResult = DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.DialogResult = DialogResult.Cancel
        Me.Close()
    End Sub

    Public Sub ResetToDefault()

    End Sub
End Class