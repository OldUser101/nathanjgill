﻿Imports MySql.Data
Imports MySql.Data.MySqlClient
Public Class Form1

    Dim connectionString As String
    Dim mySqlConnection As MySqlConnection
    Dim resetDataOnFail As Boolean
    Dim readOnlyData As Boolean
    Dim passwordChar As String
    Dim usePasswordChar As Boolean
    Dim resetOnDisconnect As Boolean

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connect.Enabled = True
        status.Text = "Status: Disconnected"
        UpdateOptions()
    End Sub

    Private Sub connect_Click(sender As Object, e As EventArgs) Handles connect.Click
        Try
            connectionString = "server=" & host.Text & ";user=" & user.Text & ";database=" & database.Text & ";password=" & password.Text & ";"
            mySqlConnection = New MySqlConnection(connectionString)
            mySqlConnection.Open()
            status.Text = "Status: Connected"
            connect.Enabled = False
            disconnect.Enabled = True
            If readOnlyData = True Then
                FreezeData()
            End If
        Catch ex As Exception
            status.Text = "Status: Failed"
            connectionString = ""
            mySqlConnection = Nothing
            MsgBox("One or more properties are invalid", MsgBoxStyle.Critical, "MySql Connection Tester")
            status.Text = "Status: Disconnected"
            connect.Enabled = True
            disconnect.Enabled = False
            If resetDataOnFail = True Then
                ResetData()
            End If
            Exit Sub
        End Try
    End Sub

    Private Sub disconnect_Click(sender As Object, e As EventArgs) Handles disconnect.Click
        Try
            mySqlConnection.Close()
            status.Text = "Status: Disconnected"
            connect.Enabled = True
            disconnect.Enabled = False
            connectionString = ""
            mySqlConnection = Nothing
            If resetOnDisconnect = True Then
                MeltAndClearData()
            Else
                MeltData()
            End If
        Catch ex As Exception
            status.Text = "Status: Failed"
            connectionString = ""
            mySqlConnection = Nothing
            MsgBox("One or more properties are invalid", MsgBoxStyle.Critical)
            status.Text = "Status: Connected"
            connect.Enabled = False
            disconnect.Enabled = True
            Exit Sub
        End Try
    End Sub

    Public Sub ResetData()
        host.Text = "Host..."
        database.Text = "Database..."
        user.Text = "User..."
        password.Text = "Password..."
    End Sub

    Public Sub FreezeData()
        host.ReadOnly = True
        database.ReadOnly = True
        user.ReadOnly = True
        password.ReadOnly = True
    End Sub

    Public Sub MeltData()
        host.ReadOnly = False
        database.ReadOnly = False
        user.ReadOnly = False
        password.ReadOnly = False
    End Sub

    Public Sub MeltAndClearData()
        MeltData()
        ResetData()
    End Sub

    Public Sub Button1_Click(sender As Object, e As EventArgs) Handles options.Click
        Form2.ShowDialog()
        If Form2.DialogResult = DialogResult.OK Then
            UpdateOptions()
        End If
    End Sub

    Public Sub UpdateOptions()
        resetDataOnFail = My.Settings.resetDataOnFail
        readOnlyData = My.Settings.readOnlyDataOnConnected
        usePasswordChar = My.Settings.usePasswordChar
        passwordChar = My.Settings.passwordChar
        resetOnDisconnect = My.Settings.resetOnDisconnected
        If usePasswordChar = True Then
            password.PasswordChar = passwordChar
        Else
            password.PasswordChar = ""
        End If
    End Sub

End Class
