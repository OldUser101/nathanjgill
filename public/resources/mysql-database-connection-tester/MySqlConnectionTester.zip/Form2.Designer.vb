﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.resetOnFail = New System.Windows.Forms.CheckBox()
        Me.usePasswordChar = New System.Windows.Forms.CheckBox()
        Me.readOnlyData = New System.Windows.Forms.CheckBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.passwordChar = New System.Windows.Forms.TextBox()
        Me.resetOnDisconnect = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'resetOnFail
        '
        Me.resetOnFail.AutoSize = True
        Me.resetOnFail.Checked = True
        Me.resetOnFail.CheckState = System.Windows.Forms.CheckState.Checked
        Me.resetOnFail.Location = New System.Drawing.Point(12, 12)
        Me.resetOnFail.Name = "resetOnFail"
        Me.resetOnFail.Size = New System.Drawing.Size(109, 17)
        Me.resetOnFail.TabIndex = 0
        Me.resetOnFail.Text = "Reset data on fail"
        Me.resetOnFail.UseVisualStyleBackColor = True
        '
        'usePasswordChar
        '
        Me.usePasswordChar.AutoSize = True
        Me.usePasswordChar.Location = New System.Drawing.Point(12, 81)
        Me.usePasswordChar.Name = "usePasswordChar"
        Me.usePasswordChar.Size = New System.Drawing.Size(141, 17)
        Me.usePasswordChar.TabIndex = 1
        Me.usePasswordChar.Text = "Use password character"
        Me.usePasswordChar.UseVisualStyleBackColor = True
        '
        'readOnlyData
        '
        Me.readOnlyData.AutoSize = True
        Me.readOnlyData.Checked = True
        Me.readOnlyData.CheckState = System.Windows.Forms.CheckState.Checked
        Me.readOnlyData.Location = New System.Drawing.Point(12, 35)
        Me.readOnlyData.Name = "readOnlyData"
        Me.readOnlyData.Size = New System.Drawing.Size(183, 17)
        Me.readOnlyData.TabIndex = 2
        Me.readOnlyData.Text = "Read-Only data when connected"
        Me.readOnlyData.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(18, 136)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "OK"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(100, 136)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 6
        Me.Button2.Text = "Cancel"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'passwordChar
        '
        Me.passwordChar.Location = New System.Drawing.Point(30, 102)
        Me.passwordChar.MaxLength = 1
        Me.passwordChar.Name = "passwordChar"
        Me.passwordChar.ReadOnly = True
        Me.passwordChar.Size = New System.Drawing.Size(113, 20)
        Me.passwordChar.TabIndex = 7
        Me.passwordChar.Text = "*"
        '
        'resetOnDisconnect
        '
        Me.resetOnDisconnect.AutoSize = True
        Me.resetOnDisconnect.Checked = True
        Me.resetOnDisconnect.CheckState = System.Windows.Forms.CheckState.Checked
        Me.resetOnDisconnect.Location = New System.Drawing.Point(12, 58)
        Me.resetOnDisconnect.Name = "resetOnDisconnect"
        Me.resetOnDisconnect.Size = New System.Drawing.Size(148, 17)
        Me.resetOnDisconnect.TabIndex = 8
        Me.resetOnDisconnect.Text = "Reset data on disconnect"
        Me.resetOnDisconnect.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(28, 177)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(66, 13)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Powered by:"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox1.Location = New System.Drawing.Point(100, 173)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(51, 50)
        Me.PictureBox1.TabIndex = 10
        Me.PictureBox1.TabStop = False
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(29, 193)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(62, 45)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "Written by Nathan Gill 2021"
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(192, 239)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.resetOnDisconnect)
        Me.Controls.Add(Me.passwordChar)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.readOnlyData)
        Me.Controls.Add(Me.usePasswordChar)
        Me.Controls.Add(Me.resetOnFail)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Options"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents resetOnFail As CheckBox
    Friend WithEvents usePasswordChar As CheckBox
    Friend WithEvents readOnlyData As CheckBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents passwordChar As TextBox
    Friend WithEvents resetOnDisconnect As CheckBox
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label2 As Label
End Class
